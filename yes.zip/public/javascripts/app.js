var mainModule = angular.module('main', []); // add services

mainModule.controller()
