# [padevo.info](http://padevo.info/)

A simple web application whose goal is to help "Puzzles and Dragons" players by quickly generating a list of materials requried to evole a monster.There's still a lot of work to be done, this is a simple prototype as of now... 

Everything is hosted on Digital Ocean using their Ubuntu servers and the code on this repository may not reflect everything as some information is private :). 

Thanks to the folks over at [PADherder](https://www.padherder.com/api/) for their public API, without them this wouldn't have been possible for me. 
