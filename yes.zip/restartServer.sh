killall node
nodemon npm start
