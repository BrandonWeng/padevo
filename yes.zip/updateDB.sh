#!/bin/bash
killall node
rm list_of_monsters.js
node data.js
